const $ = id => document.getElementById(id);

const MODEL_CONFIGS = {
  "gemini-2.5": { label: "Gemini 2.5", inputPer1M: 1.25, outputPer1M: 10.0 },
  "gemini-3.1-flash-lite": { label: "Gemini 3.1 Flash-Lite", inputPer1M: 0.35, outputPer1M: 1.05 },
  "gemini-3.5": { label: "Gemini 3.5", inputPer1M: 2.5, outputPer1M: 15.0 }
};

let currentState = { running: false, results: [], yearly: [], logs: [], errors: [] };
let currentPlan = null;
let lastResolution = { targets: [], ambiguous: [], unresolved: [], method: "not_started" };
let lastUsage = { model: "Chrome-only", inputTokens: 0, outputTokens: 0, usd: 0, twd: 0 };
let companyDictionary = [];
let codeIndex = new Map();
let aliasIndex = new Map();
let currentCompanyCsv = "";
let companyDictionarySource = "原始參考檔案 CSV";
let voiceRecognition = null;
let voiceListening = false;
let activeSystemPrompt = "";
const CLEAR_ALL = "CLEAR_ALL";
const DEFAULT_CRAWLER_URL = "https://mopsov.twse.com.tw/mops/web/t05st01";
const DEFAULT_GEMINI_MODEL = "gemini-3.1-flash-lite";
const DEFAULT_COMPANY_CSV_PATH = "data/company_reference_default.csv";
const SYSTEM_PROMPT_UNLOCK_PASSWORD = "falo";
const PLAN_FIELD_IDS = ["companyCode", "saveHtml", "yearStart", "yearEnd", "queryDateStart", "queryDateEnd"];
const TAIPEI_TIME_ZONE = "Asia/Taipei";
const DEFAULT_SYSTEM_PROMPT = [
  "You are resolving Taiwan listed/public company names into official company codes.",
  "Your job is to turn the user's natural-language request into strict JSON for a Chrome Extension crawler.",
  "Prefer local dictionary candidates when they clearly match.",
  "If ambiguous, keep multiple candidates and mark requiresUserConfirmation true.",
  "Use ROC years when the user writes Taiwan years, and do not invent unavailable company codes.",
  "If the user writes a Gregorian year such as 2025年 or 西元2025年, convert it to ROC year 114.",
  "For relative time words such as this month, this year, 本月, 這個月, or 今年, use the Current date context supplied below.",
  "For 去年第四季 in this teaching project, map to previous Gregorian year, ROC previous year, and months 9 through 12 when the user defines Q4 as 9-12.",
  "For 下半年 use months 7-12. For 上半年 or 前兩季 use months 1-6. For 單數月份 or 奇數月份 keep only odd months such as 7,9,11.",
  "Return JSON only. No markdown.",
  "Schema: { targets:[{code:string,name:string}], yearStart:number, yearEnd:number, queryMonth:number|null, queryMonthStart:number|null, queryMonthEnd:number|null, queryMonths:number[]|null, queryDateStart:string, queryDateEnd:string, saveHtml:boolean, exportFormats:string[], requiresUserConfirmation:boolean, notes:string[] }."
].join("\n");

function sendMessage(message) {
  if (!globalThis.chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
    const previewLog = {
      ts: formatTaipeiTimestamp(),
      message: "預覽模式：localhost 頁面沒有 Chrome Extension background 權限，請載入未封裝外掛後執行資料捕捉"
    };
    const previewState = {
      ...currentState,
      running: false,
      logs: [...(currentState.logs || []), previewLog],
      errors: [
        ...(currentState.errors || []),
        { error: "preview_mode_no_extension_background", message: previewLog.message }
      ]
    };
    return Promise.resolve({ ok: false, error: previewLog.message, state: previewState });
  }
  return new Promise(resolve => chrome.runtime.sendMessage(message, resolve));
}

function runtimeUrl(path) {
  if (globalThis.chrome && chrome.runtime && chrome.runtime.getURL) return chrome.runtime.getURL(path);
  return path;
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function getTaipeiParts(now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TAIPEI_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  }).formatToParts(now).reduce((acc, part) => {
    if (part.type !== "literal") acc[part.type] = part.value;
    return acc;
  }, {});
  return {
    year: parts.year,
    month: parts.month,
    day: parts.day,
    hour: parts.hour,
    minute: parts.minute,
    second: parts.second
  };
}

function formatTaipeiTimestamp(now = new Date()) {
  const parts = getTaipeiParts(now);
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:${parts.second}+08:00`;
}

function formatTaipeiStamp(now = new Date()) {
  const parts = getTaipeiParts(now);
  return `${parts.year}${parts.month}${parts.day}T${parts.hour}${parts.minute}${parts.second}`;
}

function getAiMode() {
  return $("modeGemini").checked ? "gemini" : "chrome";
}

function getAutomationMode() {
  const field = $("automationMode");
  return field ? field.value || "page_bound_browser" : "page_bound_browser";
}

function getCrawlerUrl() {
  return $("crawlerUrl").value.trim() || DEFAULT_CRAWLER_URL;
}

function getSpeechRecognitionConstructor() {
  return globalThis.SpeechRecognition || globalThis.webkitSpeechRecognition || null;
}

function setVoiceStatus(message, state = "") {
  const field = $("voiceInputStatus");
  if (!field) return;
  field.textContent = message;
  field.classList.toggle("active", state === "active");
  field.classList.toggle("warn", state === "warn");
}

function setVoicePermissionAction(visible) {
  const button = $("openVoicePermissionBtn");
  if (button) button.hidden = !visible;
}

function setVoiceButtonListening(listening) {
  voiceListening = listening;
  const button = $("voiceInputBtn");
  if (!button) return;
  button.textContent = listening ? "停止語音" : "語音輸入";
  button.setAttribute("aria-pressed", listening ? "true" : "false");
}

function stopVoiceInput() {
  if (voiceRecognition && voiceListening) {
    voiceRecognition.stop();
  }
  setVoiceButtonListening(false);
  setVoiceStatus("語音輸入待命");
}

async function requestMicrophoneAccess() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    return { ok: false, reason: "mediaDevices-unavailable" };
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach(track => track.stop());
    return { ok: true };
  } catch (error) {
    return {
      ok: false,
      reason: error && (error.name || error.message) ? (error.name || error.message) : "not-allowed"
    };
  }
}

function openVoicePermissionPage() {
  const url = runtimeUrl("voice_permission.html");
  if (globalThis.chrome && chrome.tabs && chrome.tabs.create) {
    chrome.tabs.create({ url });
    return;
  }
  window.open(url, "_blank", "noopener");
}

function explainVoiceError(error) {
  const normalized = String(error || "").toLowerCase();
  if (normalized.includes("not-allowed") || normalized.includes("notallowed") || normalized.includes("permission")) {
    setVoicePermissionAction(true);
    return "語音輸入需要麥克風權限；請先開啟麥克風權限頁並允許。";
  }
  if (normalized.includes("no-speech")) return "沒有偵測到語音，請再試一次。";
  if (normalized.includes("audio-capture") || normalized.includes("notfound")) return "找不到可用麥克風，請檢查裝置。";
  return `語音輸入無法使用：${error || "unknown"}`;
}

async function startVoiceInput() {
  const Recognition = getSpeechRecognitionConstructor();
  if (!Recognition) {
    setVoiceStatus("此瀏覽器不支援語音輸入", "warn");
    setVoicePermissionAction(false);
    return;
  }
  if (voiceListening) {
    stopVoiceInput();
    return;
  }
  setVoicePermissionAction(false);
  const permission = await requestMicrophoneAccess();
  if (!permission.ok) {
    setVoiceButtonListening(false);
    setVoiceStatus(explainVoiceError(permission.reason), "warn");
    return;
  }
  voiceRecognition = new Recognition();
  voiceRecognition.lang = "zh-TW";
  voiceRecognition.continuous = false;
  voiceRecognition.interimResults = true;
  voiceRecognition.maxAlternatives = 1;
  voiceRecognition.onstart = () => {
    setVoiceButtonListening(true);
    setVoiceStatus("正在聆聽...", "active");
  };
  voiceRecognition.onresult = event => {
    const transcript = Array.from(event.results)
      .map(result => result[0] && result[0].transcript ? result[0].transcript : "")
      .join("")
      .trim();
    if (transcript) {
      $("aiPrompt").value = transcript;
      setVoiceStatus(event.results[event.results.length - 1].isFinal ? "已填入語音文字" : "正在辨識...", "active");
    }
  };
  voiceRecognition.onerror = event => {
    setVoiceButtonListening(false);
    const error = event && event.error ? event.error : "unknown";
    setVoiceStatus(explainVoiceError(error), "warn");
  };
  voiceRecognition.onend = () => {
    setVoiceButtonListening(false);
    if (!$("voiceInputStatus").classList.contains("warn")) setVoiceStatus("語音輸入待命");
  };
  try {
    voiceRecognition.start();
  } catch (error) {
    setVoiceButtonListening(false);
    setVoiceStatus(explainVoiceError(error && error.message ? error.message : "啟動失敗"), "warn");
  }
}

function estimateTokens(text) {
  return Math.max(1, Math.ceil(String(text || "").length / 4));
}

function normalizeAlias(value) {
  return String(value || "")
    .replace(/\s+/g, "")
    .replace(/[，,。．.、:：;；()（）「」『』"'`]/g, "")
    .trim();
}

async function loadJson(path) {
  const response = await fetch(runtimeUrl(path));
  if (!response.ok) throw new Error(`讀取 ${path} 失敗`);
  return response.json();
}

async function loadText(path) {
  const response = await fetch(runtimeUrl(path));
  if (!response.ok) throw new Error(`讀取 ${path} 失敗`);
  return response.text();
}

function parseCsvRows(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  const source = String(text || "").replace(/^\uFEFF/, "");
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    const next = source[index + 1];
    if (quoted) {
      if (char === '"' && next === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else if (char !== "\r") {
      cell += char;
    }
  }
  if (cell || row.length) {
    row.push(cell);
    rows.push(row);
  }
  return rows.filter(item => item.some(value => String(value || "").trim()));
}

function parseCompanyCsv(text) {
  const rows = parseCsvRows(text);
  if (rows.length < 2) throw new Error("CSV 至少需要標題列與一筆公司資料");
  const headers = rows[0].map(item => normalizeAlias(item).toLowerCase());
  const indexOf = name => headers.indexOf(normalizeAlias(name).toLowerCase());
  const codeIndexInCsv = indexOf("code");
  const nameIndexInCsv = indexOf("primary_name");
  if (codeIndexInCsv < 0 || nameIndexInCsv < 0) {
    throw new Error("CSV 欄位至少需要 code 與 primary_name");
  }
  const marketIndex = indexOf("market");
  const aliasesIndex = indexOf("aliases");
  const evidenceIndex = indexOf("evidence_count");
  return rows.slice(1).map(row => {
    const code = String(row[codeIndexInCsv] || "").trim();
    const primaryName = String(row[nameIndexInCsv] || "").trim();
    const aliases = String(aliasesIndex >= 0 ? row[aliasesIndex] || "" : "")
      .split(/[;；|]/)
      .map(item => item.trim())
      .filter(Boolean);
    if (primaryName) aliases.unshift(primaryName);
    return {
      code,
      primary_name: primaryName,
      short_names: [primaryName].filter(Boolean),
      aliases: Array.from(new Set(aliases)),
      markets: [String(marketIndex >= 0 ? row[marketIndex] || "" : "").trim()].filter(Boolean),
      evidence_count: Number(evidenceIndex >= 0 ? row[evidenceIndex] || 0 : 0)
    };
  }).filter(item => item.code && item.primary_name);
}

function csvCell(value) {
  const text = String(value == null ? "" : value);
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function serializeCompanyCsv(dictionary = companyDictionary) {
  const lines = ["code,primary_name,market,aliases,evidence_count"];
  for (const item of dictionary) {
    const aliases = Array.from(new Set([...(item.aliases || []), ...(item.short_names || []), item.primary_name].filter(Boolean))).join(";");
    const market = item.markets && item.markets.length ? item.markets[0] : "";
    lines.push([item.code, item.primary_name, market, aliases, item.evidence_count || 0].map(csvCell).join(","));
  }
  return `${lines.join("\n")}\n`;
}

function hydrateCompanyDictionary(dictionary, csvText, source) {
  companyDictionary = dictionary;
  currentCompanyCsv = csvText || serializeCompanyCsv(dictionary);
  companyDictionarySource = source;
  codeIndex = new Map(dictionary.map(item => [String(item.code), item]));
  aliasIndex = new Map();
  for (const item of dictionary) {
    const aliases = Array.from(new Set([item.primary_name, ...(item.short_names || []), ...(item.aliases || [])].filter(Boolean)));
    for (const alias of aliases) {
      const normalized = normalizeAlias(alias);
      if (!normalized) continue;
      const existing = aliasIndex.get(normalized) || { alias, matches: [] };
      if (!existing.matches.some(match => String(match.code) === String(item.code))) {
        existing.matches.push({
          code: String(item.code),
          primary_name: item.primary_name,
          score: item.evidence_count || 1
        });
      }
      aliasIndex.set(normalized, existing);
    }
  }
  renderCompanyDictionaryStatus();
}

function renderCompanyDictionaryStatus(message = "") {
  if (!$("companyDictionarySource") || !$("companyDictionaryStatus")) return;
  $("companyDictionarySource").textContent = companyDictionarySource;
  $("companyDictionaryStatus").textContent = message || `已載入 ${companyDictionary.length} 筆公司資料，可用於名稱反解析。`;
}

async function getStoredCompanyCsv() {
  if (!globalThis.chrome || !chrome.storage) return "";
  const items = await chrome.storage.local.get(["customCompanyCsv"]);
  return items.customCompanyCsv || "";
}

async function loadCompanyCsvDictionary(forceDefault = false) {
  const storedCsv = forceDefault ? "" : await getStoredCompanyCsv();
  const csvText = storedCsv || await loadText(DEFAULT_COMPANY_CSV_PATH);
  const source = storedCsv ? "使用者匯入 CSV" : "原始參考檔案 CSV";
  hydrateCompanyDictionary(parseCompanyCsv(csvText), csvText, source);
}

async function loadCompanyDictionary() {
  if (companyDictionary.length) return;
  try {
    await loadCompanyCsvDictionary();
  } catch (error) {
    const [dictionary] = await Promise.all([
      loadJson("data/company_dictionary.json"),
      loadJson("data/company_name_index.json")
    ]);
    hydrateCompanyDictionary(dictionary, serializeCompanyCsv(dictionary), "JSON fallback");
    renderCompanyDictionaryStatus(`CSV 載入失敗，已改用 JSON fallback：${error.message}`);
  }
}

function exportCompanyCsv() {
  const csv = currentCompanyCsv || serializeCompanyCsv();
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `openquery-company-dictionary-${formatTaipeiStamp()}.csv`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

async function importCompanyCsv(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const csvText = await file.text();
  const dictionary = parseCompanyCsv(csvText);
  if (globalThis.chrome && chrome.storage) {
    await chrome.storage.local.set({ customCompanyCsv: csvText });
  }
  hydrateCompanyDictionary(dictionary, csvText, "使用者匯入 CSV");
  renderCompanyDictionaryStatus(`已匯入 ${dictionary.length} 筆公司資料：${file.name}`);
  event.target.value = "";
}

async function restoreDefaultCompanyCsv() {
  if (globalThis.chrome && chrome.storage) {
    await chrome.storage.local.remove(["customCompanyCsv"]);
  }
  companyDictionary = [];
  await loadCompanyCsvDictionary(true);
  renderCompanyDictionaryStatus("已還原為原始參考檔案 CSV。");
}

function chooseCompanyCsvFile() {
  $("importCompanyCsvInput").click();
}

function switchTab(tabName) {
  const isAdvanced = tabName === "advanced";
  $("operationsPanel").hidden = isAdvanced;
  $("advancedPanel").hidden = !isAdvanced;
  $("operationsPanel").classList.toggle("active", !isAdvanced);
  $("advancedPanel").classList.toggle("active", isAdvanced);
  $("tabOperations").classList.toggle("active", !isAdvanced);
  $("tabAdvanced").classList.toggle("active", isAdvanced);
  $("tabOperations").setAttribute("aria-selected", String(!isAdvanced));
  $("tabAdvanced").setAttribute("aria-selected", String(isAdvanced));
}

function getCurrentDateContext(now = new Date()) {
  const parts = getTaipeiParts(now);
  const currentGregorianYear = Number(parts.year);
  const currentMonth = Number(parts.month);
  const currentRocYear = currentGregorianYear - 1911;
  return {
    currentGregorianYear,
    currentRocYear,
    currentMonth,
    todayIso: `${parts.year}-${parts.month}-${parts.day}`
  };
}

function estimateCost({ modelId, inputTokens, outputTokens, exchangeRate }) {
  if (!modelId || modelId === "chrome") {
    return { model: "Chrome-only", inputTokens: 0, outputTokens: 0, usd: 0, twd: 0 };
  }
  const config = MODEL_CONFIGS[modelId] || MODEL_CONFIGS[DEFAULT_GEMINI_MODEL];
  const usd = (inputTokens / 1_000_000 * config.inputPer1M) + (outputTokens / 1_000_000 * config.outputPer1M);
  return {
    model: config.label,
    inputTokens,
    outputTokens,
    usd,
    twd: usd * Number($("exchangeRate").value || exchangeRate || 30)
  };
}

function targetFromCode(code, source = "local_code") {
  const item = codeIndex.get(String(code));
  return {
    code: String(code),
    name: item ? item.primary_name : "",
    market: item && item.markets ? item.markets[0] || "" : "",
    aliases: item ? item.aliases || [] : [],
    evidenceCount: item ? item.evidence_count || 0 : 0,
    confidence: item ? "high" : "medium",
    source
  };
}

function addUniqueTarget(targets, target) {
  if (!target || !target.code || targets.some(item => item.code === target.code)) return;
  targets.push(target);
}

function mergeCompanyTargets(...groups) {
  const merged = [];
  for (const group of groups) {
    for (const item of group || []) addUniqueTarget(merged, item);
  }
  return merged;
}

function extractCompanyCodeHints(text) {
  const raw = String(text || "");
  const ignoredAsYears = new Set(
    Array.from(raw.matchAll(/(?:西元|公元)?\s*((?:19|20)\d{2})\s*年/g)).map(match => match[1])
  );
  const hints = new Set();
  for (const match of raw.matchAll(/\b\d{4,6}\b/g)) {
    if (!ignoredAsYears.has(match[0])) hints.add(match[0]);
  }
  return hints;
}

function cleanCompanyHintSegment(segment) {
  return String(segment || "")
    .replace(/幫我|請|麻煩|協助|查詢|查|搜尋|取得|抓取|下載|匯出|完成後/gi, "")
    .replace(/重大訊息|公開資訊|資料|CSV|JSON|HTML|報表|結果/gi, "")
    .replace(/(?:西元|公元)?\s*(?:19|20)\d{2}\s*年/gi, "")
    .replace(/(?:民國)?\s*\d{2,3}\s*(?:到|至|~|-|－)\s*(?:民國)?\s*\d{2,3}\s*年?/gi, "")
    .replace(/(?:民國)?\s*\d{2,3}\s*年/gi, "")
    .replace(/這個月|本月|當月|今年|本年|去年|上半年|下半年|前兩季|第?[一二三四1234]\s*(?:季|季度|q)|單數月份|奇數月份|雙數月份|偶數月份/gi, "")
    .replace(/[，,。．.、:：;；()（）「」『』"'`]/g, "")
    .trim();
}

function extractDelimitedCompanyHints(text) {
  const raw = String(text || "");
  const parts = raw.split(/[、,，;；]|(?:\s+和\s+)|(?:\s+及\s+)|(?:\s+與\s+)|(?:\s*&\s*)|(?:\s+and\s+)/i);
  if (parts.length <= 1) return [];
  return parts
    .map(cleanCompanyHintSegment)
    .filter(segment => segment.length >= 2 && !/^\d+$/.test(segment));
}

function extractCompanyHints(text) {
  const raw = String(text || "");
  const hints = extractCompanyCodeHints(raw);
  for (const hint of extractDelimitedCompanyHints(raw)) hints.add(hint);
  for (const [normalized, item] of aliasIndex.entries()) {
    if (normalized.length < 2) continue;
    if (normalizeAlias(raw).includes(normalized)) hints.add(item.alias);
  }
  return Array.from(hints);
}

function resolveCompanyTargets(prompt, parsedTargets = []) {
  const parsedTargetCandidates = [];
  const localTargets = [];
  const ambiguous = [];
  const unresolved = [];
  const localMatches = [];

  for (const item of parsedTargets || []) {
    const code = String(item.code || item.companyCode || "").trim();
    if (code) addUniqueTarget(parsedTargetCandidates, { ...targetFromCode(code, "ai_json"), name: item.name || targetFromCode(code).name });
  }

  for (const hint of extractCompanyHints(prompt)) {
    const normalized = normalizeAlias(hint);
    if (/^\d{4,6}$/.test(hint)) {
      const target = targetFromCode(hint);
      addUniqueTarget(localTargets, target);
      localMatches.push({ hint, type: "code", matches: [target] });
      continue;
    }

    const indexed = aliasIndex.get(normalized);
    if (!indexed || !indexed.matches.length) {
      unresolved.push(hint);
      continue;
    }
    localMatches.push({ hint, type: "alias", matches: indexed.matches });
    if (indexed.matches.length === 1) {
      const match = indexed.matches[0];
      addUniqueTarget(localTargets, {
        ...targetFromCode(match.code, "local_alias"),
        name: match.primary_name,
        matchedAlias: indexed.alias,
        evidenceCount: match.score || targetFromCode(match.code).evidenceCount,
        confidence: match.score >= 8 ? "high" : "medium"
      });
    } else {
      ambiguous.push({ hint, matches: indexed.matches });
    }
  }

  let resolvedTargets = mergeCompanyTargets(parsedTargetCandidates, localTargets);
  if (!resolvedTargets.length && !ambiguous.length && !unresolved.length) {
    addUniqueTarget(resolvedTargets, targetFromCode("2330", "default"));
  }

  return {
    method: "local_dictionary",
    targets: mergeCompanyTargets(resolvedTargets),
    ambiguous,
    unresolved,
    localMatches,
    needsWebVerification: Boolean(ambiguous.length || unresolved.length),
    requiresUserConfirmation: true
  };
}

function normalizeTargetsFromGemini(parsed) {
  const targets = [];
  const rawTargets = parsed.targets || parsed.companies || [];
  if (Array.isArray(rawTargets)) {
    for (const item of rawTargets) {
      if (typeof item === "string") {
        if (/^\d{4,6}$/.test(item)) targets.push({ code: item });
      } else if (item && (item.code || item.companyCode)) {
        targets.push({ code: item.code || item.companyCode, name: item.name || item.companyName || "" });
      }
    }
  }
  if (Array.isArray(parsed.companyCodes)) {
    parsed.companyCodes.forEach(code => targets.push({ code }));
  }
  if (parsed.companyCode) targets.push({ code: parsed.companyCode, name: parsed.companyName || "" });
  return targets;
}

function buildResolutionPrompt(prompt, localResolution) {
  const candidates = [
    ...localResolution.targets.map(item => `${item.code} ${item.name} confidence=${item.confidence}`),
    ...localResolution.ambiguous.flatMap(item => item.matches.map(match => `${match.code} ${match.primary_name} ambiguous_for=${item.hint}`))
  ].slice(0, 24);
  const dateContext = getCurrentDateContext();
  return [
    getSystemPrompt(),
    `Current date context: Gregorian ${dateContext.currentGregorianYear}-${String(dateContext.currentMonth).padStart(2, "0")}, ROC year ${dateContext.currentRocYear}, current month ${dateContext.currentMonth}.`,
    `Local candidates:\n${candidates.join("\n") || "none"}`,
    `User request:\n${prompt}`
  ].join("\n\n");
}

function parseRelativeTime(prompt) {
  const text = String(prompt || "");
  const context = getCurrentDateContext();
  const previousRocYear = context.currentRocYear - 1;
  const quarter = text.match(/(第?[一二三四1234])\s*(?:季|季度|q)/i);
  const hasPreviousYear = /去年|上一年|前一年|last\s+year/i.test(text);
  if (hasPreviousYear && quarter) {
    const label = quarter[1].replace(/^第/, "");
    const ranges = {
      "一": [1, 3],
      "1": [1, 3],
      "二": [4, 6],
      "2": [4, 6],
      "三": [7, 9],
      "3": [7, 9],
      "四": [9, 12],
      "4": [9, 12]
    };
    const range = ranges[label];
    if (range) {
      return {
        yearStart: previousRocYear,
        yearEnd: previousRocYear,
        queryMonth: null,
        queryMonthStart: range[0],
        queryMonthEnd: range[1],
        queryMonths: null
      };
    }
  }
  if (hasPreviousYear) {
    return {
      yearStart: previousRocYear,
      yearEnd: previousRocYear,
      queryMonth: null,
      queryMonthStart: null,
      queryMonthEnd: null,
      queryMonths: null
    };
  }
  if (/這個月|本月|當月|這月|本月份|這月份/i.test(text)) {
    return {
      yearStart: context.currentRocYear,
      yearEnd: context.currentRocYear,
      queryMonth: context.currentMonth,
      queryMonthStart: context.currentMonth,
      queryMonthEnd: context.currentMonth,
      queryMonths: [context.currentMonth]
    };
  }
  if (/今年|本年|這一年|今年度|本年度/i.test(text)) {
    return {
      yearStart: context.currentRocYear,
      yearEnd: context.currentRocYear,
      queryMonth: null,
      queryMonthStart: null,
      queryMonthEnd: null,
      queryMonths: null
    };
  }
  return {};
}

function parseGregorianYear(prompt) {
  const text = String(prompt || "");
  return Array.from(text.matchAll(/(?:西元|公元)?\s*((?:19|20)\d{2})\s*年/g))
    .map(match => Number(match[1]) - 1911)
    .filter(year => year >= 1 && year <= 199);
}

function formatRocDate(year, month, day) {
  const y = Number(year);
  const m = Number(month);
  const d = Number(day);
  if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) return "";
  if (y < 1 || y > 199 || m < 1 || m > 12 || d < 1 || d > 31) return "";
  return `${y}/${String(m).padStart(2, "0")}/${String(d).padStart(2, "0")}`;
}

function clampRocYearForMops(year) {
  const value = Number(year);
  if (!Number.isFinite(value)) return 115;
  return Math.min(199, Math.max(80, Math.round(value)));
}

function parseDateRange(prompt) {
  const text = String(prompt || "");
  const slashRange = text.match(/(\d{2,3})[/-](\d{1,2})[/-](\d{1,2})\s*(?:到|至|~|－|-)\s*(?:(\d{2,3})[/-])?(\d{1,2})[/-](\d{1,2})/);
  if (slashRange) {
    const startYear = Number(slashRange[1]);
    const startMonth = Number(slashRange[2]);
    const startDay = Number(slashRange[3]);
    const endYear = Number(slashRange[4] || startYear);
    const endMonth = Number(slashRange[5]);
    const endDay = Number(slashRange[6]);
    return {
      yearStart: startYear,
      yearEnd: endYear,
      queryMonth: startMonth === endMonth ? startMonth : null,
      queryMonthStart: startMonth,
      queryMonthEnd: endMonth,
      queryMonths: startMonth === endMonth ? [startMonth] : null,
      queryDateStart: formatRocDate(startYear, startMonth, startDay),
      queryDateEnd: formatRocDate(endYear, endMonth, endDay)
    };
  }
  const chineseRange = text.match(/(\d{2,3})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日?\s*(?:到|至|~|－|-)\s*(?:(\d{2,3})\s*年\s*)?(?:(\d{1,2})\s*月\s*)?(\d{1,2})\s*日?/);
  if (chineseRange) {
    const startYear = Number(chineseRange[1]);
    const startMonth = Number(chineseRange[2]);
    const startDay = Number(chineseRange[3]);
    const endYear = Number(chineseRange[4] || startYear);
    const endMonth = Number(chineseRange[5] || startMonth);
    const endDay = Number(chineseRange[6]);
    return {
      yearStart: startYear,
      yearEnd: endYear,
      queryMonth: startMonth === endMonth ? startMonth : null,
      queryMonthStart: startMonth,
      queryMonthEnd: endMonth,
      queryMonths: startMonth === endMonth ? [startMonth] : null,
      queryDateStart: formatRocDate(startYear, startMonth, startDay),
      queryDateEnd: formatRocDate(endYear, endMonth, endDay)
    };
  }
  return {};
}

function parseExplicitMonth(prompt) {
  const text = String(prompt || "");
  const numeric = text.match(/(?:^|[^\d])((?:0?[1-9])|(?:1[0-2]))\s*(?:月|月份)/);
  if (numeric) return Number(numeric[1]);
  const chinese = text.match(/(十二|十一|十[一二]|十|[一二三四五六七八九正])\s*(?:月|月份)/);
  if (!chinese) return null;
  const map = {
    "正": 1,
    "一": 1,
    "二": 2,
    "三": 3,
    "四": 4,
    "五": 5,
    "六": 6,
    "七": 7,
    "八": 8,
    "九": 9,
    "十": 10,
    "十一": 11,
    "十二": 12
  };
  return map[chinese[1]] || null;
}

function stripDateExpressionsForYearParsing(prompt) {
  return String(prompt || "")
    .replace(/\d{2,3}[/-]\d{1,2}[/-]\d{1,2}\s*(?:到|至|~|－|-)\s*(?:\d{2,3}[/-])?\d{1,2}[/-]\d{1,2}/g, " ")
    .replace(/\d{2,3}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日?\s*(?:到|至|~|－|-)\s*(?:\d{2,3}\s*年\s*)?(?:\d{1,2}\s*月\s*)?\d{1,2}\s*日?/g, " ");
}

function parseMonthSet(prompt, seed = {}) {
  const text = String(prompt || "");
  let start = seed.queryMonthStart || null;
  let end = seed.queryMonthEnd || null;
  let months = Array.isArray(seed.queryMonths) && seed.queryMonths.length ? [...seed.queryMonths] : null;
  const quarter = text.match(/(第?[一二三四1234])\s*(?:季|季度|q)/i);
  const quarterRanges = {
    "一": [1, 3],
    "1": [1, 3],
    "二": [4, 6],
    "2": [4, 6],
    "三": [7, 9],
    "3": [7, 9],
    "四": [10, 12],
    "4": [10, 12]
  };
  if (/下半年|後半年|下半年度/i.test(text)) {
    start = 7;
    end = 12;
  } else if (/上半年|前半年|上半年度|前兩季|前二季|前\s*2\s*季/i.test(text)) {
    start = 1;
    end = 6;
  } else if (quarter && !(seed.queryMonthStart && seed.queryMonthEnd)) {
    const range = quarterRanges[quarter[1].replace(/^第/, "")];
    if (range) {
      start = range[0];
      end = range[1];
    }
  }
  const explicitMonth = parseExplicitMonth(text);
  if (!months && !start && !end && explicitMonth) {
    start = explicitMonth;
    end = explicitMonth;
    months = [explicitMonth];
  }
  if (!months && start && end) {
    months = Array.from({ length: end - start + 1 }, (_, index) => start + index);
  }
  const oddMonthsOnly = /單數月份|奇數月份|單數月|奇數月|odd\s+months?/i.test(text);
  const evenMonthsOnly = /雙數月份|偶數月份|雙數月|偶數月|even\s+months?/i.test(text);
  if (oddMonthsOnly || evenMonthsOnly) {
    const source = months || Array.from({ length: 12 }, (_, index) => index + 1);
    months = source.filter(month => oddMonthsOnly ? month % 2 === 1 : month % 2 === 0);
    start = null;
    end = null;
  }
  if (months) {
    months = Array.from(new Set(months.map(Number).filter(month => month >= 1 && month <= 12))).sort((a, b) => a - b);
    if (months.length === 1) {
      return { queryMonth: months[0], queryMonthStart: months[0], queryMonthEnd: months[0], queryMonths: months };
    }
    return { queryMonth: null, queryMonthStart: start, queryMonthEnd: end, queryMonths: months };
  }
  return { queryMonth: seed.queryMonth || null, queryMonthStart: start, queryMonthEnd: end, queryMonths: null };
}

function parseYears(prompt) {
  const dateRange = parseDateRange(prompt);
  const text = stripDateExpressionsForYearParsing(prompt);
  const relative = parseRelativeTime(prompt);
  const gregorianYears = parseGregorianYear(prompt);
  const years = gregorianYears.length ? gregorianYears : Array.from(text.matchAll(/(?:民國)?\s*(\d{2,3})\s*(?:年)?/g))
    .map(match => Number(match[1]))
    .filter(year => year >= 80 && year <= 199);
  let yearStart = Number($("yearStart").value || 100);
  let yearEnd = Number($("yearEnd").value || 114);
  const seed = Object.keys(dateRange).length ? dateRange : relative;
  const monthSet = parseMonthSet(prompt, seed);
  let queryMonth = monthSet.queryMonth || null;
  let queryMonthStart = monthSet.queryMonthStart || null;
  let queryMonthEnd = monthSet.queryMonthEnd || null;
  let queryMonths = monthSet.queryMonths || null;
  let queryDateStart = dateRange.queryDateStart || "";
  let queryDateEnd = dateRange.queryDateEnd || "";
  if (dateRange.yearStart && dateRange.yearEnd) {
    yearStart = dateRange.yearStart;
    yearEnd = dateRange.yearEnd;
  } else if (years.length >= 2) {
    yearStart = Math.min(years[0], years[1]);
    yearEnd = Math.max(years[0], years[1]);
  } else if (years.length === 1) {
    yearStart = years[0];
    yearEnd = years[0];
  } else if (relative.yearStart && relative.yearEnd) {
    yearStart = relative.yearStart;
    yearEnd = relative.yearEnd;
  }
  return { yearStart, yearEnd, queryMonth, queryMonthStart, queryMonthEnd, queryMonths, queryDateStart, queryDateEnd };
}

function mergeTimeFields(localTime, aiTime) {
  const merged = { ...(localTime || {}) };
  for (const key of ["queryMonth", "queryMonthStart", "queryMonthEnd"]) {
    if ((merged[key] == null || merged[key] === "") && aiTime && aiTime[key] != null && aiTime[key] !== "") {
      merged[key] = aiTime[key];
    }
  }
  if ((!Array.isArray(merged.queryMonths) || !merged.queryMonths.length) && aiTime && Array.isArray(aiTime.queryMonths) && aiTime.queryMonths.length) {
    merged.queryMonths = aiTime.queryMonths;
  }
  for (const key of ["queryDateStart", "queryDateEnd"]) {
    if (!merged[key] && aiTime && aiTime[key]) merged[key] = aiTime[key];
  }
  return merged;
}

function parseOptions(prompt) {
  const text = String(prompt || "");
  const saveHtml = /保存|保留|html|原始/i.test(text);
  const exportFormats = [];
  if (/csv/i.test(text) || /下載|匯出/.test(text)) exportFormats.push("csv");
  if (/json/i.test(text)) exportFormats.push("json");
  if (exportFormats.length === 0) exportFormats.push("csv");
  return { saveHtml, exportFormats };
}

function buildOperationPlan(input) {
  const yearStart = clampRocYearForMops(input.yearStart || 100);
  const yearEnd = clampRocYearForMops(input.yearEnd || 114);
  const normalizedStart = Math.min(yearStart, yearEnd);
  const normalizedEnd = Math.max(yearStart, yearEnd);
  const targets = Array.isArray(input.targets) && input.targets.length
    ? input.targets.map(item => ({
      code: String(item.code || item.companyCode || "").trim(),
      name: item.name || item.companyName || "",
      confidence: item.confidence || "medium",
      source: item.source || "manual"
    })).filter(item => item.code)
    : [{ code: String(input.companyCode || "2330"), name: input.companyName || "", confidence: "manual", source: "manual" }];
  const automationMode = input.automationMode || getAutomationMode();
  const queryMonths = Array.isArray(input.queryMonths)
    ? Array.from(new Set(input.queryMonths.map(Number).filter(month => month >= 1 && month <= 12))).sort((a, b) => a - b)
    : null;
  const queryDateStart = String(input.queryDateStart || "").trim();
  const queryDateEnd = String(input.queryDateEnd || "").trim();
  const hasMonthFilter = Boolean(input.queryMonth || input.queryMonthStart || (queryMonths && queryMonths.length));
  const hasDateFilter = Boolean(queryDateStart || queryDateEnd);
  return {
    source: "official_mops_t05st01",
    companyCode: targets[0] ? targets[0].code : "2330",
    targets,
    yearStart: normalizedStart,
    yearEnd: normalizedEnd,
    queryMonth: input.queryMonth == null ? null : Number(input.queryMonth),
    queryMonthStart: input.queryMonthStart == null ? null : Number(input.queryMonthStart),
    queryMonthEnd: input.queryMonthEnd == null ? null : Number(input.queryMonthEnd),
    queryMonths: queryMonths && queryMonths.length ? queryMonths : null,
    queryDateStart,
    queryDateEnd,
    saveHtml: Boolean(input.saveHtml),
    exportFormats: Array.isArray(input.exportFormats) && input.exportFormats.length ? input.exportFormats : ["csv"],
    entryUrl: input.entryUrl || getCrawlerUrl(),
    automationMode,
    humanPacedDelayMs: automationMode === "human_paced_browser" ? Number(input.humanPacedDelayMs || 1800) : 350,
    openStrategy: input.openStrategy || "current_or_bound_window",
    forceFreshWindow: Boolean(input.forceFreshWindow),
    estimatedQueries: targets.length * (normalizedEnd - normalizedStart + 1),
    requiresConfirmation: true,
    autoRunDemo: Boolean(input.autoRunDemo),
    blockedReason: input.blockedReason || "",
    actions: automationMode === "api_data_flow"
      ? ["try_public_data_endpoint", "parse_response", hasMonthFilter ? "filter_month" : "", hasDateFilter ? "filter_date" : "", "show_results"].filter(Boolean)
      : ["bind_mops_page", "query_years", "parse_table", hasMonthFilter ? "filter_month" : "", hasDateFilter ? "filter_date" : "", "show_results"].filter(Boolean)
  };
}

function parseChromeOnlyPrompt(prompt) {
  const resolution = resolveCompanyTargets(prompt);
  lastResolution = resolution;
  return buildOperationPlan({
    ...parseYears(prompt),
    ...parseOptions(prompt),
    targets: resolution.targets,
    automationMode: getAutomationMode(),
    blockedReason: resolution.needsWebVerification ? "有公司名稱需要確認或網路驗證" : ""
  });
}

async function applyDataFlowDemoPreset() {
  $("aiPrompt").value = "高效資料流展示：查 2330 台積電 113 到 115 年重大訊息，完成後下載 CSV";
  await loadCompanyDictionary();
  lastResolution = resolveCompanyTargets($("aiPrompt").value, [{ code: "2330", name: "台積電" }]);
  await runDemoPlan(buildOperationPlan({
    targets: lastResolution.targets,
    yearStart: 113,
    yearEnd: 115,
    saveHtml: false,
    exportFormats: ["csv"],
    entryUrl: DEFAULT_CRAWLER_URL,
    automationMode: "api_data_flow",
    openStrategy: "fresh_demo_window",
    forceFreshWindow: true,
    autoRunDemo: true
  }));
}

async function applyHumanPacedDemoPreset() {
  $("aiPrompt").value = "AI 瀏覽器操作展示：查 2330 台積電 115 年 5 月 1 日到 5 月 31 日重大訊息，放慢節奏呈現 AI Browser / AI Agent 趨勢";
  await loadCompanyDictionary();
  lastResolution = resolveCompanyTargets($("aiPrompt").value, [{ code: "2330", name: "台積電" }]);
  await runDemoPlan(buildOperationPlan({
    targets: lastResolution.targets,
    yearStart: 115,
    yearEnd: 115,
    queryMonth: 5,
    queryMonthStart: 5,
    queryMonthEnd: 5,
    queryMonths: [5],
    queryDateStart: "115/05/01",
    queryDateEnd: "115/05/31",
    saveHtml: false,
    exportFormats: ["csv"],
    entryUrl: DEFAULT_CRAWLER_URL,
    automationMode: "human_paced_browser",
    humanPacedDelayMs: 1800,
    openStrategy: "fresh_demo_window",
    forceFreshWindow: true,
    autoRunDemo: true
  }));
}

function setDemoButtonsDisabled(disabled) {
  $("dataFlowDemoBtn").disabled = disabled;
  $("humanPacedDemoBtn").disabled = disabled;
}

async function runDemoPlan(plan) {
  try {
    setDemoButtonsDisabled(true);
    renderPlan(plan);
    $("confirmRunBtn").disabled = true;
    $("logBox").innerHTML += `<div>[demo] 展示模式：開新視窗並執行固定流程</div>`;
    const response = await sendMessage({ type: "CONFIRM_RUN", plan: { ...plan, keepOriginalHtml: plan.saveHtml } });
    if (response && response.state) renderState(response.state);
  } finally {
    setDemoButtonsDisabled(false);
    $("confirmRunBtn").disabled = true;
  }
}

function extractJsonObject(text) {
  const raw = String(text || "");
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end < start) throw new Error("Gemini 回應沒有 JSON 物件");
  return JSON.parse(raw.slice(start, end + 1));
}

async function callGeminiForPlan(prompt) {
  const apiKey = $("apiKey").value.trim();
  if (!apiKey) throw new Error("請先輸入 Gemini API Key");
  const modelId = $("geminiModel").value;
  const localResolution = resolveCompanyTargets(prompt);
  const instruction = buildResolutionPrompt(prompt, localResolution);
  const body = {
    contents: [{ role: "user", parts: [{ text: instruction }] }],
    generationConfig: { temperature: 0.1 }
  };
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(modelId)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const payload = await response.json();
  if (!response.ok) {
    throw new Error(payload.error && payload.error.message ? payload.error.message : `Gemini HTTP ${response.status}`);
  }
  const outputText = (((payload.candidates || [])[0] || {}).content || {}).parts?.map(part => part.text || "").join("") || "";
  const parsed = extractJsonObject(outputText);
  const geminiTargets = normalizeTargetsFromGemini(parsed);
  const mergedResolution = resolveCompanyTargets(prompt, geminiTargets);
  mergedResolution.method = localResolution.needsWebVerification ? "local_dictionary_plus_gemini" : "local_dictionary_verified_by_gemini";
  lastResolution = mergedResolution;
  const usage = payload.usageMetadata || {};
  const inputTokens = usage.promptTokenCount || estimateTokens(instruction);
  const outputTokens = usage.candidatesTokenCount || estimateTokens(outputText);
  lastUsage = estimateCost({
    modelId,
    inputTokens,
    outputTokens,
    exchangeRate: $("exchangeRate").value
  });
  return buildOperationPlan({
    ...parseOptions(prompt),
    ...parsed,
    ...mergeTimeFields(parseYears(prompt), parsed),
    targets: mergedResolution.targets,
    automationMode: getAutomationMode(),
    blockedReason: mergedResolution.needsWebVerification ? "AI 已輔助解析，但仍有候選需要人工確認" : ""
  });
}

function renderResolution(resolution = lastResolution) {
  const targetCount = resolution.targets ? resolution.targets.length : 0;
  const ambiguousCount = resolution.ambiguous ? resolution.ambiguous.length : 0;
  const unresolvedCount = resolution.unresolved ? resolution.unresolved.length : 0;
  $("resolutionPreview").textContent = [
    `方法：${resolution.method || "not_started"}`,
    `已選目標：${targetCount}`,
    `模糊候選：${ambiguousCount}`,
    `未解析：${unresolvedCount}`
  ].join("｜");
  const targetHtml = (resolution.targets || []).map(item => `
    <div class="target">
      <strong>${escapeHtml(item.code)} ${escapeHtml(item.name || "")}</strong>
      <span class="meta">來源：${escapeHtml(item.source || "")}｜信心：${escapeHtml(item.confidence || "")}｜evidence：${escapeHtml(item.evidenceCount || "")}</span>
    </div>
  `).join("");
  const ambiguousHtml = (resolution.ambiguous || []).map(item => `
    <div class="target warn">
      <strong>${escapeHtml(item.hint)} 需要確認</strong>
      <span class="meta">${escapeHtml(item.matches.map(match => `${match.code} ${match.primary_name}`).join(" / "))}</span>
    </div>
  `).join("");
  const unresolvedHtml = (resolution.unresolved || []).map(item => `
    <div class="target warn">
      <strong>${escapeHtml(item)} 未解析</strong>
      <span class="meta">可切換 Gemini API 輔助確認，或直接輸入公司代號。</span>
    </div>
  `).join("");
  $("targetList").innerHTML = targetHtml + ambiguousHtml + unresolvedHtml;
}

function markPlanFieldState(id, state) {
  const field = $(id);
  if (!field) return;
  field.dataset.fillState = state;
  const labels = {
    ai: "AI 解析填入，會作為執行條件",
    manual: "使用者手動調整，會覆寫 AI 解析",
    empty: "空白，未作為條件",
    default: "預設值"
  };
  field.title = labels[state] || "";
}

function hasPlanFieldValue(id) {
  const field = $(id);
  if (!field) return false;
  if (field.tagName === "SELECT") return true;
  return String(field.value || "").trim() !== "";
}

function markAiPlanFields(plan) {
  for (const id of PLAN_FIELD_IDS) {
    markPlanFieldState(id, plan && hasPlanFieldValue(id) ? "ai" : "empty");
  }
}

function markManualPlanField(event) {
  const field = event && event.currentTarget;
  if (!field) return;
  markPlanFieldState(field.id, hasPlanFieldValue(field.id) ? "manual" : "empty");
}

function resetPlanFieldStates() {
  for (const id of PLAN_FIELD_IDS) {
    markPlanFieldState(id, hasPlanFieldValue(id) ? "default" : "empty");
  }
}

function renderPlan(plan) {
  currentPlan = plan;
  $("planPreview").textContent = JSON.stringify(plan || { status: "尚未解析" }, null, 2);
  const canRun = Boolean(plan && plan.targets && plan.targets.length && !(lastResolution.ambiguous || []).length && !(lastResolution.unresolved || []).length);
  $("confirmRunBtn").disabled = !canRun;
  if (plan) {
    $("companyCode").value = plan.companyCode;
    $("yearStart").value = plan.yearStart;
    $("yearEnd").value = plan.yearEnd;
    $("queryDateStart").value = plan.queryDateStart || "";
    $("queryDateEnd").value = plan.queryDateEnd || "";
    $("saveHtml").value = String(Boolean(plan.saveHtml));
    const automationModeField = $("automationMode");
    if (automationModeField) automationModeField.value = plan.automationMode || getAutomationMode();
    markAiPlanFields(plan);
  } else {
    resetPlanFieldStates();
  }
  renderResolution();
}

function renderCost(cost = lastUsage) {
  $("costModel").textContent = cost.model;
  $("inputTokens").textContent = String(cost.inputTokens || 0);
  $("outputTokens").textContent = String(cost.outputTokens || 0);
  $("costUsd").textContent = `$${Number(cost.usd || 0).toFixed(6)}`;
  $("costTwd").textContent = `NT$${Number(cost.twd || 0).toFixed(2)}`;
}

function companyKey(row) {
  return `${row.companyCode || ""} ${row.companyName || ""}`.trim() || "未標示公司";
}

function buildBalancedPreviewRows(rows, limit = 80) {
  const source = Array.isArray(rows) ? rows : [];
  if (source.length <= limit) return source;
  const groups = new Map();
  for (const row of source) {
    const key = companyKey(row);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  }
  if (groups.size <= 1) return source.slice(0, limit);
  const groupedRows = Array.from(groups.values());
  const preview = [];
  let index = 0;
  while (preview.length < limit) {
    let added = false;
    for (const group of groupedRows) {
      if (group[index] && preview.length < limit) {
        preview.push(group[index]);
        added = true;
      }
    }
    if (!added) break;
    index += 1;
  }
  return preview;
}

function renderResultCompanySummary(rows) {
  const field = $("resultCompanySummary");
  if (!field) return;
  const counts = new Map();
  for (const row of rows || []) {
    const key = companyKey(row);
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  field.innerHTML = Array.from(counts.entries()).map(([key, count]) =>
    `<span class="company-pill">${escapeHtml(key)}：${count} 筆</span>`
  ).join("");
}

function renderState(state) {
  currentState = state || currentState;
  $("boundStatus").textContent = currentState.boundTabId ? `已綁定 Tab ${currentState.boundTabId}` : "尚未綁定";
  $("boundUrl").textContent = currentState.boundUrl || "官方 MOPS t05st01";
  $("totalRows").textContent = currentState.results.length;
  $("doneYears").textContent = currentState.yearly.length;
  $("errorCount").textContent = currentState.errors.length;
  $("csvBtn").disabled = currentState.results.length === 0;
  $("jsonBtn").disabled = currentState.results.length === 0;
  $("htmlReportBtn").disabled = currentState.results.length === 0;
  $("htmlInteractiveBtn").disabled = currentState.results.length === 0;
  renderResultCompanySummary(currentState.results);
  $("recordBody").innerHTML = buildBalancedPreviewRows(currentState.results, 80).map(row => `
    <tr>
      <td>${escapeHtml(row.queryYear)}</td>
      <td>${escapeHtml(row.announceDate)}</td>
      <td>${escapeHtml(row.companyName || row.companyCode)}</td>
      <td>${escapeHtml(row.subject || row.rawText)}</td>
    </tr>
  `).join("");
  $("logBox").innerHTML = currentState.logs.slice(-120).map(item => {
    const time = item.ts ? item.ts.slice(11, 19) : "";
    return `<div>[${escapeHtml(time)}] ${escapeHtml(item.message)}</div>`;
  }).join("");
  $("logBox").scrollTop = $("logBox").scrollHeight;
}

async function parsePrompt() {
  try {
    await loadCompanyDictionary();
    const prompt = $("aiPrompt").value;
    if (getAiMode() === "gemini") {
      const plan = await callGeminiForPlan(prompt);
      renderPlan(plan);
      renderCost(lastUsage);
    } else {
      const plan = parseChromeOnlyPrompt(prompt);
      renderPlan(plan);
      lastUsage = estimateCost({ modelId: "chrome", inputTokens: 0, outputTokens: 0, exchangeRate: $("exchangeRate").value });
      renderCost(lastUsage);
    }
  } catch (error) {
    lastResolution = { targets: [], ambiguous: [], unresolved: [], method: "error" };
    renderPlan({ error: String(error && error.message ? error.message : error), requiresConfirmation: false });
    $("confirmRunBtn").disabled = true;
  }
}

async function confirmRun() {
  const plan = buildOperationPlan({
    ...(currentPlan || {}),
    targets: currentPlan && currentPlan.targets && currentPlan.targets.length
      ? currentPlan.targets
      : [{ code: $("companyCode").value, name: "" }],
    yearStart: $("yearStart").value,
    yearEnd: $("yearEnd").value,
    queryDateStart: $("queryDateStart").value,
    queryDateEnd: $("queryDateEnd").value,
    saveHtml: $("saveHtml").value === "true",
    entryUrl: getCrawlerUrl(),
    automationMode: currentPlan && currentPlan.automationMode ? currentPlan.automationMode : getAutomationMode(),
    humanPacedDelayMs: currentPlan && currentPlan.humanPacedDelayMs
  });
  renderPlan(plan);
  const response = await sendMessage({ type: "CONFIRM_RUN", plan: { ...plan, keepOriginalHtml: plan.saveHtml } });
  if (response && response.state) renderState(response.state);
}

async function saveKey() {
  if (globalThis.chrome && chrome.storage) {
    await chrome.storage.local.set({
      geminiApiKey: $("apiKey").value.trim(),
      geminiModel: $("geminiModel").value || DEFAULT_GEMINI_MODEL
    });
  }
}

async function saveModelChoice() {
  if (globalThis.chrome && chrome.storage) {
    await chrome.storage.local.set({ geminiModel: $("geminiModel").value || DEFAULT_GEMINI_MODEL });
  }
}

function getSystemPrompt() {
  const editor = $("systemPromptEditor");
  const controls = $("systemPromptControls");
  const value = editor && controls && !controls.hidden ? editor.value.trim() : "";
  return value || activeSystemPrompt || DEFAULT_SYSTEM_PROMPT;
}

function setSystemPromptEditor(value, source = "default") {
  activeSystemPrompt = value || DEFAULT_SYSTEM_PROMPT;
  const controls = $("systemPromptControls");
  $("systemPromptEditor").value = controls && !controls.hidden ? activeSystemPrompt : "";
  $("systemPromptStatus").textContent = source === "saved" ? "已載入使用者儲存版本。" : "使用預設規則。";
}

function encodeSystemPrompt(value) {
  const source = new TextEncoder().encode(String(value || ""));
  const key = new TextEncoder().encode(SYSTEM_PROMPT_UNLOCK_PASSWORD);
  const mixed = Array.from(source, (byte, index) => byte ^ key[index % key.length]);
  return btoa(String.fromCharCode(...mixed));
}

function decodeSystemPrompt(value) {
  try {
    const raw = atob(String(value || ""));
    const bytes = Uint8Array.from(raw, char => char.charCodeAt(0));
    const key = new TextEncoder().encode(SYSTEM_PROMPT_UNLOCK_PASSWORD);
    const decoded = bytes.map((byte, index) => byte ^ key[index % key.length]);
    return new TextDecoder().decode(decoded);
  } catch (error) {
    return "";
  }
}

async function saveSystemPrompt() {
  const value = getSystemPrompt();
  if (globalThis.chrome && chrome.storage) {
    await chrome.storage.local.set({ systemPromptEncoded: encodeSystemPrompt(value) });
    await chrome.storage.local.remove(["systemPrompt"]);
  }
  $("systemPromptStatus").textContent = "已儲存使用者修改，storage 內採輕量編碼避免一般檢視時直接讀到規則。";
}

async function restoreSystemPrompt() {
  setSystemPromptEditor(DEFAULT_SYSTEM_PROMPT);
  if (globalThis.chrome && chrome.storage) {
    await chrome.storage.local.remove(["systemPrompt", "systemPromptEncoded"]);
  }
}

function unlockSystemPrompt() {
  const password = $("systemPromptPassword").value.trim();
  if (password !== SYSTEM_PROMPT_UNLOCK_PASSWORD) {
    $("systemPromptLockStatus").textContent = "密碼不正確。";
    return;
  }
  $("systemPromptControls").hidden = false;
  $("systemPromptEditor").value = activeSystemPrompt || DEFAULT_SYSTEM_PROMPT;
  $("systemPromptLockStatus").textContent = "已解鎖，可檢視與修改 System Prompt。";
  $("systemPromptPassword").value = "";
}

function lockSystemPrompt() {
  $("systemPromptControls").hidden = true;
  $("systemPromptEditor").value = "";
  $("systemPromptLockStatus").textContent = "已鎖定";
}

async function clearKey() {
  $("apiKey").value = "";
  if (globalThis.chrome && chrome.storage) await chrome.storage.local.remove(["geminiApiKey"]);
}

async function testGemini() {
  const originalPrompt = $("aiPrompt").value;
  $("aiPrompt").value = "查 2330 114 年重大訊息";
  await parsePrompt();
  $("aiPrompt").value = originalPrompt;
}

async function clearAll() {
  await clearKey();
  lastResolution = { targets: [], ambiguous: [], unresolved: [], method: "not_started" };
  renderPlan(null);
  renderCost(estimateCost({ modelId: "chrome", inputTokens: 0, outputTokens: 0, exchangeRate: $("exchangeRate").value }));
  const response = await sendMessage({ type: CLEAR_ALL });
  if (response && response.state) renderState(response.state);
}

async function copyCrawlerUrl() {
  const value = getCrawlerUrl();
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(value);
    } else {
      const area = document.createElement("textarea");
      area.value = value;
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    $("copyCrawlerUrlBtn").textContent = "已複製";
    window.setTimeout(() => { $("copyCrawlerUrlBtn").textContent = "複製網址"; }, 1200);
  } catch (error) {
    $("copyCrawlerUrlBtn").textContent = "複製失敗";
    window.setTimeout(() => { $("copyCrawlerUrlBtn").textContent = "複製網址"; }, 1200);
  }
}

function bindEvents() {
  $("openBindBtn").addEventListener("click", async () => {
    const response = await sendMessage({ type: "OPEN_BIND", options: { entryUrl: getCrawlerUrl() } });
    if (response && response.state) renderState(response.state);
  });
  $("bindActiveBtn").addEventListener("click", async () => {
    const response = await sendMessage({ type: "BIND_ACTIVE" });
    if (response && response.state) renderState(response.state);
  });
  $("tabOperations").addEventListener("click", () => switchTab("operations"));
  $("tabAdvanced").addEventListener("click", () => switchTab("advanced"));
  $("saveKeyBtn").addEventListener("click", saveKey);
  $("unlockSystemPromptBtn").addEventListener("click", unlockSystemPrompt);
  $("saveSystemPromptBtn").addEventListener("click", saveSystemPrompt);
  $("restoreSystemPromptBtn").addEventListener("click", restoreSystemPrompt);
  $("lockSystemPromptBtn").addEventListener("click", lockSystemPrompt);
  $("exportCompanyCsvBtn").addEventListener("click", exportCompanyCsv);
  $("importCompanyCsvBtn").addEventListener("click", chooseCompanyCsvFile);
  $("importCompanyCsvInput").addEventListener("change", importCompanyCsv);
  $("restoreCompanyCsvBtn").addEventListener("click", restoreDefaultCompanyCsv);
  $("copyCrawlerUrlBtn").addEventListener("click", copyCrawlerUrl);
  $("testGeminiBtn").addEventListener("click", testGemini);
  $("clearKeyBtn").addEventListener("click", clearKey);
  $("dataFlowDemoBtn").addEventListener("click", applyDataFlowDemoPreset);
  $("humanPacedDemoBtn").addEventListener("click", applyHumanPacedDemoPreset);
  $("voiceInputBtn").addEventListener("click", startVoiceInput);
  $("openVoicePermissionBtn").addEventListener("click", openVoicePermissionPage);
  $("parseBtn").addEventListener("click", parsePrompt);
  $("clearPromptBtn").addEventListener("click", () => { $("aiPrompt").value = ""; });
  for (const id of PLAN_FIELD_IDS) {
    const field = $(id);
    if (field) {
      field.addEventListener("input", markManualPlanField);
      field.addEventListener("change", markManualPlanField);
    }
  }
  $("confirmRunBtn").addEventListener("click", confirmRun);
  $("cancelPlanBtn").addEventListener("click", () => renderPlan(null));
  $("csvBtn").addEventListener("click", () => sendMessage({ type: "DOWNLOAD", kind: "csv" }));
  $("jsonBtn").addEventListener("click", () => sendMessage({ type: "DOWNLOAD", kind: "json" }));
  $("htmlReportBtn").addEventListener("click", () => sendMessage({ type: "DOWNLOAD", kind: "html_report" }));
  $("htmlInteractiveBtn").addEventListener("click", () => sendMessage({ type: "DOWNLOAD", kind: "html_interactive" }));
  $("clearResultsBtn").addEventListener("click", async () => {
    const response = await sendMessage({ type: "CLEAR_RESULTS" });
    if (response && response.state) renderState(response.state);
  });
  $("clearAllBtn").addEventListener("click", clearAll);
  $("geminiModel").addEventListener("change", () => {
    saveModelChoice();
    renderCost(estimateCost({
      modelId: getAiMode() === "gemini" ? $("geminiModel").value : "chrome",
      inputTokens: lastUsage.inputTokens,
      outputTokens: lastUsage.outputTokens,
      exchangeRate: $("exchangeRate").value
    }));
  });
  $("exchangeRate").addEventListener("input", () => renderCost(estimateCost({
    modelId: getAiMode() === "gemini" ? $("geminiModel").value : "chrome",
    inputTokens: lastUsage.inputTokens,
    outputTokens: lastUsage.outputTokens,
    exchangeRate: $("exchangeRate").value
  })));
}

async function init() {
  bindEvents();
  if (!getSpeechRecognitionConstructor()) setVoiceStatus("此瀏覽器不支援語音輸入", "warn");
  renderResolution();
  renderCost();
  setSystemPromptEditor(DEFAULT_SYSTEM_PROMPT);
  lockSystemPrompt();
  try {
    await loadCompanyDictionary();
    $("resolutionPreview").textContent = `公司字典已載入：${companyDictionary.length} 筆公司資料`;
  } catch (error) {
    $("resolutionPreview").textContent = `公司字典載入失敗：${error.message}`;
  }
  if (globalThis.chrome && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener(message => {
      if (message.type === "STATE_UPDATE") renderState(message.state);
    });
  }
  if (globalThis.chrome && chrome.storage) {
    chrome.storage.local.get(["geminiApiKey", "geminiModel", "systemPrompt", "systemPromptEncoded"]).then(items => {
      if (items.geminiApiKey) $("apiKey").value = items.geminiApiKey;
      if (items.geminiModel && MODEL_CONFIGS[items.geminiModel]) {
        $("geminiModel").value = items.geminiModel;
      } else {
        $("geminiModel").value = DEFAULT_GEMINI_MODEL;
      }
      if (items.systemPromptEncoded) {
        setSystemPromptEditor(decodeSystemPrompt(items.systemPromptEncoded), "saved");
      } else if (items.systemPrompt) {
        setSystemPromptEditor(items.systemPrompt, "saved");
      }
    });
  }
  sendMessage({ type: "GET_STATE" }).then(response => renderState(response && response.state));
}

init();
