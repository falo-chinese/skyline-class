importScripts("parser.js");

const MOPS_ENTRY_URL = "https://mops.twse.com.tw/mops/web/t05st01";
const MOPS_OV_ENTRY_URL = "https://mopsov.twse.com.tw/mops/web/t05st01";
const TAIPEI_TIME_ZONE = "Asia/Taipei";

const state = {
  running: false,
  startedAt: "",
  finishedAt: "",
  companyCode: "2330",
  companyName: "台積電",
  targets: [{ code: "2330", name: "台積電" }],
  automationMode: "page_bound_browser",
  entryUrl: MOPS_OV_ENTRY_URL,
  openStrategy: "current_or_bound_window",
  boundTabId: null,
  boundWindowId: null,
  boundUrl: "",
  results: [],
  yearly: [],
  logs: [],
  errors: []
};

chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
});

function getTaipeiParts(now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TAIPEI_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  }).formatToParts(now).reduce((acc, part) => {
    if (part.type !== "literal") acc[part.type] = part.value;
    return acc;
  }, {});
  return {
    year: parts.year,
    month: parts.month,
    day: parts.day,
    hour: parts.hour,
    minute: parts.minute,
    second: parts.second
  };
}

function formatTaipeiTimestamp(now = new Date()) {
  const parts = getTaipeiParts(now);
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:${parts.second}+08:00`;
}

function formatTaipeiStamp(now = new Date()) {
  const parts = getTaipeiParts(now);
  return `${parts.year}${parts.month}${parts.day}T${parts.hour}${parts.minute}${parts.second}`;
}

function resetRun(options = {}) {
  const targets = Array.isArray(options.targets) && options.targets.length
    ? options.targets
    : [{ code: options.companyCode || "2330", name: options.companyName || "" }];
  state.running = true;
  state.startedAt = formatTaipeiTimestamp();
  state.finishedAt = "";
  state.targets = targets;
  state.companyCode = targets[0] ? String(targets[0].code || targets[0].companyCode || "2330") : "2330";
  state.companyName = targets[0] ? String(targets[0].name || targets[0].companyName || "") : "";
  state.automationMode = options.automationMode || "page_bound_browser";
  state.entryUrl = options.entryUrl || MOPS_OV_ENTRY_URL;
  state.openStrategy = options.openStrategy || "current_or_bound_window";
  state.queryMonth = options.queryMonth == null ? null : Number(options.queryMonth);
  state.queryMonthStart = options.queryMonthStart == null ? null : Number(options.queryMonthStart);
  state.queryMonthEnd = options.queryMonthEnd == null ? null : Number(options.queryMonthEnd);
  state.queryMonths = Array.isArray(options.queryMonths)
    ? options.queryMonths.map(Number).filter(month => month >= 1 && month <= 12)
    : null;
  state.queryDateStart = options.queryDateStart || "";
  state.queryDateEnd = options.queryDateEnd || "";
  state.results = [];
  state.yearly = [];
  state.logs = [];
  state.errors = [];
}

function log(message, extra = {}) {
  const item = { ts: formatTaipeiTimestamp(), message, ...extra };
  state.logs.push(item);
  chrome.runtime.sendMessage({ type: "STATE_UPDATE", state }).catch(() => {});
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function normalizeYears(yearStart, yearEnd) {
  const start = clampRocYearForMops(yearStart);
  const end = clampRocYearForMops(yearEnd);
  const lo = Math.min(start, end);
  const hi = Math.max(start, end);
  const years = [];
  for (let year = lo; year <= hi; year += 1) years.push(String(year));
  return years;
}

function clampRocYearForMops(year) {
  const value = Number(year);
  if (!Number.isFinite(value)) return 115;
  return Math.min(199, Math.max(80, Math.round(value)));
}

function normalizeMonth(month) {
  const value = Number(month);
  if (!Number.isFinite(value) || value < 1 || value > 12) return null;
  return value;
}

function rowMatchesMonth(row, month) {
  const normalized = normalizeMonth(month);
  if (!normalized) return true;
  const text = String(row && row.announceDate ? row.announceDate : "");
  const match = text.match(/(?:\d{2,4})[/-](\d{1,2})[/-]\d{1,2}/);
  return match ? Number(match[1]) === normalized : false;
}

function filterRowsByMonth(rows, month) {
  const normalized = normalizeMonth(month);
  if (!normalized) return rows;
  return rows.filter(row => rowMatchesMonth(row, normalized));
}

function extractRowMonth(row) {
  const text = String(row && row.announceDate ? row.announceDate : "");
  const match = text.match(/(?:\d{2,4})[/-](\d{1,2})[/-]\d{1,2}/);
  return match ? Number(match[1]) : null;
}

function normalizeRocDate(value) {
  const text = String(value || "").trim();
  if (!text) return null;
  const match = text.match(/(\d{2,4})[/-](\d{1,2})[/-](\d{1,2})/);
  if (!match) return null;
  let year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (year >= 1912) year -= 1911;
  if (!Number.isFinite(year) || !Number.isFinite(month) || !Number.isFinite(day)) return null;
  if (year < 1 || month < 1 || month > 12 || day < 1 || day > 31) return null;
  return year * 10000 + month * 100 + day;
}

function extractRowDateKey(row) {
  return normalizeRocDate(row && row.announceDate ? row.announceDate : "");
}

function filterRowsByDateRange(rows, start, end) {
  const startKey = normalizeRocDate(start);
  const endKey = normalizeRocDate(end);
  if (!startKey && !endKey) return rows;
  const lo = startKey && endKey ? Math.min(startKey, endKey) : startKey || endKey;
  const hi = startKey && endKey ? Math.max(startKey, endKey) : startKey || endKey;
  return rows.filter(row => {
    const dateKey = extractRowDateKey(row);
    return dateKey ? dateKey >= lo && dateKey <= hi : false;
  });
}

function normalizeMonthSet(months) {
  if (!Array.isArray(months)) return null;
  const values = Array.from(new Set(months.map(Number).filter(month => month >= 1 && month <= 12))).sort((a, b) => a - b);
  return values.length ? values : null;
}

function filterRowsByMonthSet(rows, months) {
  const values = normalizeMonthSet(months);
  if (!values) return rows;
  const allowed = new Set(values);
  return rows.filter(row => allowed.has(extractRowMonth(row)));
}

function normalizeMonthRange(start, end, singleMonth = null) {
  const single = normalizeMonth(singleMonth);
  if (single) return { start: single, end: single };
  const lo = normalizeMonth(start);
  const hi = normalizeMonth(end);
  if (!lo || !hi) return null;
  return { start: Math.min(lo, hi), end: Math.max(lo, hi) };
}

function filterRowsByMonthRange(rows, start, end, singleMonth = null) {
  const range = normalizeMonthRange(start, end, singleMonth);
  if (!range) return rows;
  return rows.filter(row => {
    const month = extractRowMonth(row);
    if (!month) return false;
    return month >= range.start && month <= range.end;
  });
}

function filterRowsByMonthCriteria(rows, options = {}) {
  const months = normalizeMonthSet(options.queryMonths);
  const monthRows = months
    ? filterRowsByMonthSet(rows, months)
    : filterRowsByMonthRange(rows, options.queryMonthStart, options.queryMonthEnd, options.queryMonth);
  return filterRowsByDateRange(monthRows, options.queryDateStart, options.queryDateEnd);
}

function waitForTabComplete(tabId, timeoutMs = 20000) {
  return new Promise(resolve => {
    let done = false;
    const timer = setTimeout(() => finish(), timeoutMs);
    function finish() {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }
    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.status === "complete") finish();
    }
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then(tab => {
      if (tab.status === "complete") finish();
    }).catch(() => finish());
  });
}

async function openCrawlerWindowAndBind(options = {}) {
  const url = options.entryUrl || MOPS_OV_ENTRY_URL || MOPS_ENTRY_URL;
  const created = await chrome.windows.create({
    url,
    type: "popup",
    focused: true,
    width: 1180,
    height: 820
  });
  const tab = created.tabs && created.tabs[0];
  state.boundWindowId = created.id || null;
  state.boundTabId = tab ? tab.id : null;
  state.boundUrl = url;
  if (state.boundTabId) await waitForTabComplete(state.boundTabId);
  log("已開啟並綁定官方 MOPS 查詢視窗", { tabId: state.boundTabId, windowId: state.boundWindowId, url });
  return { tabId: state.boundTabId, windowId: state.boundWindowId, url };
}

async function bindActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  if (!tab || !tab.id) throw new Error("找不到目前分頁");
  state.boundTabId = tab.id;
  state.boundWindowId = tab.windowId || null;
  state.boundUrl = tab.url || "";
  log("已綁定目前分頁", { tabId: state.boundTabId, windowId: state.boundWindowId, url: state.boundUrl });
  return { tabId: state.boundTabId, windowId: state.boundWindowId, url: state.boundUrl };
}

async function ensureMopsBoundTab() {
  const entryUrl = state.entryUrl || MOPS_OV_ENTRY_URL;
  if (state.boundTabId) {
    try {
      const tab = await chrome.tabs.get(state.boundTabId);
      const url = tab.url || "";
      if (/mops.*twse\.com\.tw\/mops\/web\/t05st01/.test(url)) return;
      await chrome.tabs.update(state.boundTabId, { url: entryUrl, active: true });
      await waitForTabComplete(state.boundTabId);
      state.boundUrl = entryUrl;
      return;
    } catch (error) {
      state.boundTabId = null;
      state.boundWindowId = null;
      state.boundUrl = "";
    }
  }
  await openCrawlerWindowAndBind({ entryUrl });
}

function createEvidenceRow({ companyCode, companyName, year, page, sourceUrl, automationMode }) {
  const text = String((page && page.text) || "").replace(/\s+/g, " ").trim();
  return {
    recordType: "capture_evidence",
    queryYear: String(year || ""),
    companyCode: String(companyCode || ""),
    companyName: String(companyName || ""),
    announceDate: "",
    announceTime: "",
    subject: text ? "已捕捉 MOPS 查詢回應，但尚未解析成結構化列" : "未解析到結構化列",
    rawText: text.slice(0, 2000),
    sourceUrl: sourceUrl || "",
    automationMode,
    captureMethod: page && page.captureMethod ? page.captureMethod : "unknown",
    original: {
      status: page && page.ok ? 200 : "capture_only",
      bytes: page && page.html ? new Blob([page.html]).size : 0,
      html: ""
    }
  };
}

async function queryMopsYearInBoundTab(companyCode, year, options = {}) {
  await ensureMopsBoundTab();
  if (!state.boundTabId) throw new Error("尚未綁定 MOPS 查詢頁");
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId: state.boundTabId },
    world: "MAIN",
    args: [{
      companyCode,
      year,
      queryMonth: normalizeMonth(options.queryMonth),
      automationMode: options.automationMode || "page_bound_browser",
      humanPacedDelayMs: options.humanPacedDelayMs || 900
    }],
    func: async function queryMopsByButtonThenFetch({ companyCode, year, queryMonth, automationMode, humanPacedDelayMs }) {
      const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
      const pace = Math.max(350, Number(humanPacedDelayMs || 900));
      const form = document.forms.form1 || document.querySelector("form#form1");
      if (!form) throw new Error("找不到 MOPS 查詢表單 form1");

      const setValue = (name, value) => {
        const field = form.elements[name] || document.getElementById(name);
        if (field) {
          field.focus && field.focus();
          field.value = value;
          field.dispatchEvent(new Event("input", { bubbles: true }));
          field.dispatchEvent(new Event("change", { bubbles: true }));
        }
      };

      const currentTablePayload = (started, captureMethod, ok = true, error = "") => {
        const table = document.querySelector("#table01");
        return {
          ok,
          html: table ? table.outerHTML : "",
          text: table ? table.innerText || "" : "",
          pageUrl: location.href,
          elapsedMs: Date.now() - started,
          captureMethod,
          error
        };
      };

      const waitForResult = async (before, started, captureMethod, timeoutMs = 18000) => {
        while (Date.now() - started < timeoutMs) {
          const table = document.querySelector("#table01");
          const html = table ? table.innerHTML : "";
          const text = table ? table.innerText || "" : "";
          const hasRequestedYear = text.includes(`${year}/`) || text.includes(`${Number(year) + 1911}/`) || /查無資料|無符合|無此公司/.test(text);
          if (html && html !== before && !/資料載入中|loading/i.test(html) && hasRequestedYear) {
            if (automationMode === "human_paced_browser") {
              table.scrollIntoView({ behavior: "smooth", block: "start" });
              await sleep(pace);
            }
            return currentTablePayload(started, captureMethod, true);
          }
          await sleep(250);
        }
        return null;
      };

      const fetchFallback = async started => {
        const data = new URLSearchParams();
        for (const element of Array.from(form.elements)) {
          if (element.name) data.set(element.name, element.value || "");
        }
        const response = await fetch(form.action || "/mops/web/ajax_t05st01", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
          body: data.toString(),
          credentials: "same-origin"
        });
        const rawHtml = await response.text();
        const html = /<table/i.test(rawHtml) ? rawHtml : `<table id="table01">${rawHtml}</table>`;
        const holder = document.querySelector("#table01");
        if (holder) {
          if (/<table/i.test(rawHtml)) holder.outerHTML = rawHtml;
          else holder.innerHTML = rawHtml;
        }
        const text = rawHtml.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
        return {
          ok: response.ok,
          html,
          text,
          pageUrl: response.url || location.href,
          elapsedMs: Date.now() - started,
          captureMethod: "fetch_fallback",
          error: response.ok ? "" : `fetch fallback HTTP ${response.status}`
        };
      };

      if (automationMode === "human_paced_browser") {
        (form.elements.co_id || document.getElementById("co_id") || form).scrollIntoView({ behavior: "smooth", block: "center" });
        await sleep(pace);
      }
      setValue("co_id", companyCode);
      if (automationMode === "human_paced_browser") await sleep(pace);
      setValue("year", String(year));
      if (automationMode === "human_paced_browser") await sleep(pace);
      setValue("month", queryMonth ? String(queryMonth).padStart(2, "0") : "");
      setValue("TYPEK", "all");
      setValue("TYPEK2", "");
      setValue("queryName", "co_id");
      setValue("inpuType", "co_id");
      setValue("step", "1");
      setValue("firstin", "1");
      setValue("off", "1");
      form.action = "/mops/web/ajax_t05st01";

      const beforeTable = document.querySelector("#table01");
      const before = beforeTable ? beforeTable.innerHTML : "";
      const started = Date.now();
      if (automationMode === "human_paced_browser") {
        (document.querySelector("input[type='button'], input[type='submit'], button") || form).scrollIntoView({ behavior: "smooth", block: "center" });
        await sleep(pace);
      }
      const queryButton = form.querySelector("input[type='button'], input[type='submit'], button");
      if (queryButton && typeof queryButton.click === "function") {
        queryButton.click();
      } else if (typeof doAction === "function") {
        doAction();
        if (typeof ajax1 === "function") ajax1(form, "table01");
      } else if (typeof ajax1 === "function") {
        ajax1(form, "table01");
      } else if (typeof form.submit === "function") {
        form.submit();
      }

      const clicked = await waitForResult(before, started, "button_click", automationMode === "human_paced_browser" ? 20000 : 8000);
      if (clicked) return clicked;

      try {
        const fetched = await fetchFallback(started);
        if (fetched.html || fetched.text) return fetched;
      } catch (error) {
        const current = currentTablePayload(started, "fetch_fallback", false, String(error && error.message ? error.message : error));
        if (current.html || current.text) return current;
      }

      return currentTablePayload(started, "timeout", false, "等待 MOPS 查詢結果逾時");
    }
  });
  return result;
}

async function queryCompanyYears(options) {
  const companyCode = String(options.companyCode || "2330").trim();
  const companyName = String(options.companyName || "").trim();
  const years = normalizeYears(options.yearStart || 84, options.yearEnd || 115);
  const automationMode = options.automationMode || state.automationMode || "page_bound_browser";
  const monthSet = normalizeMonthSet(options.queryMonths);
  const monthRange = normalizeMonthRange(options.queryMonthStart, options.queryMonthEnd, options.queryMonth);
  const queryMonth = monthSet && monthSet.length === 1 ? monthSet[0] : monthRange && monthRange.start === monthRange.end ? monthRange.start : null;
  const humanPacedDelayMs = Math.max(350, Number(options.humanPacedDelayMs || 900));
  const defaultDelay = automationMode === "api_data_flow" ? 120 : automationMode === "human_paced_browser" ? humanPacedDelayMs : 350;
  const delayMs = Math.max(0, Number(options.delayMs || defaultDelay));
  const keepOriginalHtml = Boolean(options.keepOriginalHtml);
  if (!state.running || options.reset !== false) resetRun({ ...options, companyCode, companyName, automationMode });
  const modeLabel = automationMode === "api_data_flow" ? "API / 資料流" : automationMode === "human_paced_browser" ? "人類節奏" : "頁面綁定";
  const monthLabel = monthSet ? `，月份 ${monthSet.join(",")}` : monthRange ? monthRange.start === monthRange.end ? `，月份 ${monthRange.start}` : `，月份 ${monthRange.start}-${monthRange.end}` : "";
  const dateLabel = options.queryDateStart || options.queryDateEnd ? `，日期 ${options.queryDateStart || "起"}-${options.queryDateEnd || "迄"}` : "";
  log(`開始查詢官方 MOPS ${companyCode} ${companyName}，年度 ${years[0]}-${years[years.length - 1]}${monthLabel}${dateLabel}，模式：${modeLabel}`);

  for (const year of years) {
    try {
      log(`MOPS 查詢 ${companyCode} ${year} 年`, { companyCode, year, automationMode, url: MOPS_OV_ENTRY_URL });
      const page = await queryMopsYearInBoundTab(companyCode, year, { automationMode, humanPacedDelayMs, queryMonth });
      const parsed = TsmcParser.parseMopsResultHtml(page.html || "", {
        companyCode,
        year,
        sourceUrl: page.pageUrl || MOPS_OV_ENTRY_URL
      });
      const resultRows = filterRowsByMonthCriteria(parsed.rows, options);
      const yearlyItem = {
        year,
        url: page.pageUrl || MOPS_OV_ENTRY_URL,
        status: page.ok ? 200 : "timeout",
        bytes: new Blob([page.html || ""]).size,
        elapsedMs: page.elapsedMs,
        rows: resultRows.length,
        parsedRowsBeforeMonthFilter: parsed.rows.length,
        queryMonth: queryMonth || null,
        queryMonthStart: monthRange ? monthRange.start : null,
        queryMonthEnd: monthRange ? monthRange.end : null,
        queryMonths: monthSet || null,
        queryDateStart: options.queryDateStart || "",
        queryDateEnd: options.queryDateEnd || "",
        capped: false,
        companyCode,
        companyName,
        automationMode,
        captureMethod: page.captureMethod || "unknown",
        capturedTextLength: page.text ? page.text.length : 0,
        capturedHtmlBytes: page.html ? new Blob([page.html]).size : 0,
        totalText: parsed.rawText
      };
      state.yearly.push(yearlyItem);
      for (const row of resultRows) {
        row.recordType = row.recordType || "mops_material_info";
        row.companyCode = row.companyCode || companyCode;
        row.companyName = row.companyName || companyName;
        row.automationMode = automationMode;
        row.captureMethod = page.captureMethod || "unknown";
        row.original = {
          status: page.ok ? 200 : "timeout",
          bytes: yearlyItem.bytes,
          html: keepOriginalHtml ? page.html || "" : ""
        };
      }
      if (resultRows.length > 0) {
        state.results.push(...resultRows);
      } else if (parsed.rows.length > 0 && (monthRange || monthSet)) {
        const label = monthSet ? monthSet.join(",") : `${monthRange.start}-${monthRange.end}`;
        log(`${year} 年完成：月份 ${label} 過濾後 0 筆，原年度 ${parsed.rows.length} 筆`, yearlyItem);
      } else if (page.html || page.text) {
        const evidenceRow = createEvidenceRow({
          companyCode,
          companyName,
          year,
          page,
          sourceUrl: page.pageUrl || MOPS_OV_ENTRY_URL,
          automationMode
        });
        state.results.push(evidenceRow);
        yearlyItem.rows = 1;
        yearlyItem.evidenceOnly = true;
        log(`${year} 年完成：未解析結構化列，已保存 evidence row`, yearlyItem);
      }
      log(`${year} 年完成：${yearlyItem.rows} 筆`, yearlyItem);
    } catch (error) {
      const item = {
        year,
        url: MOPS_OV_ENTRY_URL,
        error: String(error && error.message ? error.message : error)
      };
      state.errors.push(item);
      state.yearly.push({ year, url: MOPS_OV_ENTRY_URL, status: "error", rows: 0, error: item.error });
      log(`${year} 年失敗：${item.error}`, item);
    }
    await sleep(delayMs);
  }

  if (options.reset !== false) {
    state.running = false;
    state.finishedAt = formatTaipeiTimestamp();
    log(`查詢完成：共 ${state.results.length} 筆，錯誤 ${state.errors.length} 筆`);
    chrome.storage.local.set({ lastOpenQueryAgentRun: state }).catch(() => {});
  }
  return state;
}

async function queryTargets(options) {
  const targets = Array.isArray(options.targets) && options.targets.length
    ? options.targets
    : [{ code: options.companyCode || "2330", name: options.companyName || "" }];
  resetRun({ ...options, targets });
  const forceFreshWindow = Boolean(options.forceFreshWindow || options.openStrategy === "fresh_demo_window");
  if (forceFreshWindow) {
    state.boundTabId = null;
    state.boundWindowId = null;
    state.boundUrl = "";
    log("展示模式：強制開啟全新 MOPS 視窗並綁定", {
      openStrategy: "fresh_demo_window",
      entryUrl: state.entryUrl
    });
    await openCrawlerWindowAndBind({ entryUrl: state.entryUrl || MOPS_OV_ENTRY_URL });
  }
  for (const target of targets) {
    await queryCompanyYears({
      ...options,
      reset: false,
      companyCode: target.code || target.companyCode,
      companyName: target.name || target.companyName || ""
    });
  }
  state.running = false;
  state.finishedAt = formatTaipeiTimestamp();
  log(`全部目標完成：${targets.length} 家公司，共 ${state.results.length} 筆`);
  chrome.storage.local.set({ lastOpenQueryAgentRun: state }).catch(() => {});
  return state;
}

function toCsv(rows) {
  const fields = [
    "queryYear",
    "companyCode",
    "companyName",
    "announceDate",
    "announceTime",
    "subject",
    "rawText",
    "sourceUrl",
    "recordType",
    "automationMode",
    "captureMethod",
    "originalStatus",
    "originalBytes"
  ];
  const quote = value => `"${String(value == null ? "" : value).replace(/"/g, '""')}"`;
  const lines = [fields.map(quote).join(",")];
  for (const row of rows) {
    lines.push(fields.map(field => {
      if (field === "originalStatus") return quote(row.original && row.original.status);
      if (field === "originalBytes") return quote(row.original && row.original.bytes);
      return quote(row[field]);
    }).join(","));
  }
  return "\ufeff" + lines.join("\n");
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function summarizeCompanies(rows) {
  const counts = new Map();
  for (const row of rows || []) {
    const key = `${row.companyCode || ""} ${row.companyName || ""}`.trim() || "未標示公司";
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  return Array.from(counts.entries()).map(([label, count]) => ({ label, count }));
}

function sharedHtmlHead(title) {
  return `<!doctype html>
<html lang="zh-Hant">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Falo OpenQuery Agent v1.0 report by Falo x Force Cheng 2026/6/16.">
  <meta name="author" content="Falo x Force Cheng">
  <meta name="version" content="v1.0">
  <meta name="ai-summary" content="Falo OpenQuery Agent exported MOPS public query results as a teaching artifact with evidence-oriented automation context.">
  <title>${escapeHtml(title)}</title>
  <style>
    body{margin:0;background:#f5f7fa;color:#1f2933;font-family:-apple-system,BlinkMacSystemFont,"Noto Sans TC","PingFang TC","Microsoft JhengHei",sans-serif;line-height:1.5}
    main{max-width:1180px;margin:0 auto;padding:24px}
    header,.card{background:#fff;border:1px solid #d9dee7;border-radius:8px;padding:16px;margin-bottom:14px}
    h1{margin:0 0 6px;font-size:26px} h2{margin:0 0 10px;font-size:18px}
    .muted{color:#667085}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}
    .stat,.pill{border:1px solid #d9dee7;border-radius:7px;background:#fbfcfd;padding:10px}
    .stat strong{display:block;color:#174e55;font-size:22px}.pill{display:inline-block;margin:0 6px 6px 0;color:#174e55;font-weight:650}
    table{width:100%;border-collapse:collapse;background:#fff}th,td{border-bottom:1px solid #d9dee7;padding:8px;text-align:left;vertical-align:top}th{background:#f9fafb;color:#667085;position:sticky;top:0}
    .table-wrap{max-height:70vh;overflow:auto;border:1px solid #d9dee7;border-radius:8px}
    input,select{border:1px solid #d9dee7;border-radius:7px;padding:9px;font:inherit}label{display:grid;gap:4px;color:#667085;font-size:13px}
    .hidden-watermark{position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;opacity:0}
  </style>
</head>
<body>
<div class="hidden-watermark">Falo x Force Cheng 2026/6/16 | Falo OpenQuery Agent v1.0 | exported HTML report</div>
<main>`;
}

function buildHtmlRows(rows) {
  return (rows || []).map(row => `<tr>
    <td>${escapeHtml(row.queryYear)}</td>
    <td>${escapeHtml(row.announceDate)}</td>
    <td>${escapeHtml(row.companyCode)} ${escapeHtml(row.companyName)}</td>
    <td>${escapeHtml(row.subject || row.rawText)}</td>
    <td>${escapeHtml(row.sourceUrl)}</td>
  </tr>`).join("");
}

function buildHtmlReport() {
  const rows = state.results || [];
  const companySummary = summarizeCompanies(rows);
  return `${sharedHtmlHead("Falo OpenQuery Agent 報告 HTML")}
  <header>
    <h1>Falo OpenQuery Agent 報告 HTML</h1>
    <p class="muted">Falo x Force Cheng 2026/6/16｜v1.0版｜靜態閱讀版</p>
    <p class="muted">這份報告適合交付、教學截圖、留存查詢結果摘要。若要在檔案內搜尋與篩選，請匯出互動查詢 HTML。</p>
  </header>
  <section class="card grid">
    <div class="stat"><strong>${rows.length}</strong><span>筆資料</span></div>
    <div class="stat"><strong>${state.yearly.length}</strong><span>年度/公司查詢</span></div>
    <div class="stat"><strong>${state.errors.length}</strong><span>錯誤</span></div>
    <div class="stat"><strong>${escapeHtml(state.automationMode || "")}</strong><span>自動化模式</span></div>
  </section>
  <section class="card">
    <h2>公司分布</h2>
    ${companySummary.map(item => `<span class="pill">${escapeHtml(item.label)}：${item.count} 筆</span>`).join("")}
  </section>
  <section class="card">
    <h2>查詢結果</h2>
    <div class="table-wrap"><table>
      <thead><tr><th>年</th><th>日期</th><th>公司</th><th>主旨</th><th>來源</th></tr></thead>
      <tbody>${buildHtmlRows(rows)}</tbody>
    </table></div>
  </section>
</main></body></html>`;
}

function buildInteractiveHtmlReport() {
  const rows = state.results || [];
  const companies = summarizeCompanies(rows).map(item => item.label);
  const years = Array.from(new Set(rows.map(row => row.queryYear).filter(Boolean))).sort();
  const months = Array.from(new Set(rows.map(row => extractRowMonth(row)).filter(Boolean))).sort((a, b) => a - b);
  const dataJson = JSON.stringify(rows).replace(/</g, "\\u003c");
  return `${sharedHtmlHead("Falo OpenQuery Agent 互動查詢 HTML")}
  <header>
    <h1>Falo OpenQuery Agent 互動查詢 HTML</h1>
    <p class="muted">Falo x Force Cheng 2026/6/16｜v1.0版｜離線互動查詢版</p>
  </header>
  <section class="card grid">
    <label>公司
      <select id="companyFilter"><option value="">全部公司</option>${companies.map(company => `<option value="${escapeHtml(company)}">${escapeHtml(company)}</option>`).join("")}</select>
    </label>
    <label>年度
      <select id="yearFilter"><option value="">全部年度</option>${years.map(year => `<option value="${escapeHtml(year)}">${escapeHtml(year)}</option>`).join("")}</select>
    </label>
    <label>月份
      <select id="monthFilter"><option value="">全部月份</option>${months.map(month => `<option value="${month}">${month} 月</option>`).join("")}</select>
    </label>
    <label>關鍵字
      <input id="keywordFilter" placeholder="輸入主旨關鍵字">
    </label>
    <div class="stat"><strong id="visibleCount">0</strong><span>目前顯示</span></div>
  </section>
  <section class="card">
    <h2>查詢結果</h2>
    <div class="table-wrap"><table>
      <thead><tr>
        <th><button type="button" data-sort-key="queryYear">年</button></th>
        <th><button type="button" data-sort-key="announceDate">日期</button></th>
        <th><button type="button" data-sort-key="company">公司</button></th>
        <th><button type="button" data-sort-key="subject">主旨</button></th>
        <th><button type="button" data-sort-key="sourceUrl">來源</button></th>
      </tr></thead>
      <tbody id="rowsBody"></tbody>
    </table></div>
  </section>
  <script id="openqueryData" type="application/json">${dataJson}</script>
  <script>
    const rows = JSON.parse(document.getElementById("openqueryData").textContent || "[]");
    let sortState = { key: "", direction: "asc" };
    const esc = value => String(value == null ? "" : value).replace(/[&<>"]/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;" }[ch]));
    const companyKey = row => [row.companyCode || "", row.companyName || ""].join(" ").trim();
    const rowMonth = row => {
      const match = String(row.announceDate || "").match(/(?:\\d{2,4})[/-](\\d{1,2})[/-]\\d{1,2}/);
      return match ? Number(match[1]) : null;
    };
    const sortValue = (row, key) => {
      if (key === "company") return companyKey(row);
      if (key === "subject") return row.subject || row.rawText || "";
      return row[key] || "";
    };
    function sortRows(items) {
      if (!sortState.key) return items;
      const direction = sortState.direction === "desc" ? -1 : 1;
      return [...items].sort((a, b) => String(sortValue(a, sortState.key)).localeCompare(String(sortValue(b, sortState.key)), "zh-Hant", { numeric: true }) * direction);
    }
    function toggleSort(key) {
      sortState = sortState.key === key
        ? { key, direction: sortState.direction === "asc" ? "desc" : "asc" }
        : { key, direction: "asc" };
      render();
    }
    function render() {
      const company = document.getElementById("companyFilter").value;
      const year = document.getElementById("yearFilter").value;
      const month = document.getElementById("monthFilter").value;
      const keyword = document.getElementById("keywordFilter").value.trim().toLowerCase();
      const filtered = rows.filter(row =>
        (!company || companyKey(row) === company) &&
        (!year || String(row.queryYear || "") === year) &&
        (!month || String(rowMonth(row) || "") === month) &&
        (!keyword || String(row.subject || row.rawText || "").toLowerCase().includes(keyword))
      );
      const sorted = sortRows(filtered);
      document.getElementById("visibleCount").textContent = sorted.length;
      document.getElementById("rowsBody").innerHTML = sorted.map(row => '<tr><td>' + esc(row.queryYear) + '</td><td>' + esc(row.announceDate) + '</td><td>' + esc(companyKey(row)) + '</td><td>' + esc(row.subject || row.rawText) + '</td><td>' + esc(row.sourceUrl) + '</td></tr>').join("");
    }
    document.getElementById("companyFilter").addEventListener("change", render);
    document.getElementById("yearFilter").addEventListener("change", render);
    document.getElementById("monthFilter").addEventListener("change", render);
    document.getElementById("keywordFilter").addEventListener("input", render);
    document.querySelectorAll("[data-sort-key]").forEach(button => button.addEventListener("click", () => toggleSort(button.dataset.sortKey)));
    render();
  </script>
</main></body></html>`;
}

function downloadData(kind) {
  const stamp = formatTaipeiStamp();
  const filename = kind === "json"
    ? `openquery-mops-material-info-${stamp}.json`
    : kind === "html_report"
      ? `openquery-mops-report-${stamp}.html`
      : kind === "html_interactive"
        ? `openquery-mops-interactive-${stamp}.html`
        : `openquery-mops-material-info-${stamp}.csv`;
  const content = kind === "json"
    ? JSON.stringify(state, null, 2)
    : kind === "html_report"
      ? buildHtmlReport()
      : kind === "html_interactive"
        ? buildInteractiveHtmlReport()
        : toCsv(state.results);
  const mime = kind === "json" ? "application/json" : kind.startsWith("html_") ? "text/html" : "text/csv";
  const url = `data:${mime};charset=utf-8,${encodeURIComponent(content)}`;
  return chrome.downloads.download({ url, filename, saveAs: false });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GET_STATE") {
    sendResponse({ state });
    return false;
  }
  if (message.type === "QUERY_YEARS") {
    queryTargets(message.options || {})
      .then(nextState => sendResponse({ ok: true, state: nextState }))
      .catch(error => sendResponse({ ok: false, error: String(error && error.message ? error.message : error), state }));
    return true;
  }
  if (message.type === "CONFIRM_RUN") {
    queryTargets(message.plan || message.options || {})
      .then(nextState => sendResponse({ ok: true, state: nextState }))
      .catch(error => sendResponse({ ok: false, error: String(error && error.message ? error.message : error), state }));
    return true;
  }
  if (message.type === "OPEN_BIND") {
    openCrawlerWindowAndBind(message.options || {})
      .then(bound => sendResponse({ ok: true, bound, state }))
      .catch(error => sendResponse({ ok: false, error: String(error && error.message ? error.message : error), state }));
    return true;
  }
  if (message.type === "BIND_ACTIVE") {
    bindActiveTab()
      .then(bound => sendResponse({ ok: true, bound, state }))
      .catch(error => sendResponse({ ok: false, error: String(error && error.message ? error.message : error), state }));
    return true;
  }
  if (message.type === "DOWNLOAD") {
    downloadData(message.kind || "csv")
      .then(downloadId => sendResponse({ ok: true, downloadId }))
      .catch(error => sendResponse({ ok: false, error: String(error && error.message ? error.message : error) }));
    return true;
  }
  if (message.type === "CLEAR_RESULTS" || message.type === "CLEAR_ALL") {
    state.running = false;
    state.finishedAt = "";
    state.results = [];
    state.yearly = [];
    state.logs = [];
    state.errors = [];
    chrome.storage.local.remove(["lastOpenQueryAgentRun", "lastTsmcPublicQuery"]).catch(() => {});
    sendResponse({ ok: true, state });
    return false;
  }
  return false;
});
