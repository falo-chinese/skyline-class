const statusEl = document.getElementById("permissionStatus");

function setStatus(message, state = "") {
  statusEl.textContent = message;
  statusEl.classList.toggle("active", state === "active");
  statusEl.classList.toggle("warn", state === "warn");
}

async function requestMicPermission() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    setStatus("此環境不支援麥克風權限請求。", "warn");
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach(track => track.stop());
    setStatus("麥克風權限已取得，請回到側邊欄重新按語音輸入。", "active");
  } catch (error) {
    const name = error && (error.name || error.message) ? (error.name || error.message) : "unknown";
    setStatus(`麥克風權限仍未開啟：${name}`, "warn");
  }
}

document.getElementById("requestMicPermissionBtn").addEventListener("click", requestMicPermission);
document.getElementById("closePermissionPageBtn").addEventListener("click", () => window.close());
